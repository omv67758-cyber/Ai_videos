import { describe, expect, it } from "vitest";

describe("Agnes API configuration", () => {
  it("authenticates with the configured server secret", async () => {
    const apiKey = process.env.AGNES_API_KEY ?? process.env.VIDEO_API_KEY;
    expect(apiKey, "AGNES_API_KEY or VIDEO_API_KEY must be configured").toBeTruthy();

    const response = await fetch("https://apihub.agnes-ai.com/v1/models", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });

    expect(response.ok, `Agnes API returned ${response.status}`).toBe(true);
  }, 30_000);
});
