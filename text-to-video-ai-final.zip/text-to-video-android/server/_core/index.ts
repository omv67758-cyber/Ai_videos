import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { ENV } from "./env";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Enable CORS for all routes - reflect the request origin to support credentials
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.header("Access-Control-Allow-Origin", origin);
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.post("/api/video/generate", async (req, res) => {
    if (!ENV.agnesApiKey) {
      res.status(503).json({ error: "Video API is not configured on the server." });
      return;
    }

    const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim() : "";
    const ratio = typeof req.body?.ratio === "string" ? req.body.ratio : "16:9";
    const duration = typeof req.body?.duration === "number" ? req.body.duration : 5;
    const dimensions: Record<string, { width: number; height: number }> = {
      "16:9": { width: 1152, height: 648 },
      "9:16": { width: 648, height: 1152 },
      "1:1": { width: 768, height: 768 },
    };
    const size = dimensions[ratio] ?? dimensions["16:9"];
    const seconds = Math.min(Math.max(duration, 3), 10);
    const numFrames = Math.min(241, Math.max(73, Math.round(seconds * 24 / 8) * 8 + 1));

    if (!prompt) {
      res.status(400).json({ error: "A video prompt is required." });
      return;
    }

    try {
      const upstream = await fetch("https://apihub.agnes-ai.com/v1/videos", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${ENV.agnesApiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "agnes-video-v2.0",
          prompt,
          width: size.width,
          height: size.height,
          num_frames: numFrames,
          frame_rate: 24,
        }),
      });
      const body = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        res.status(upstream.status).json({ error: body?.error?.message ?? body?.message ?? "Video provider request failed." });
        return;
      }
      res.status(202).json(body);
    } catch (error) {
      console.error("[video] provider request failed", error);
      res.status(502).json({ error: "Could not reach the video provider." });
    }
  });

  app.get("/api/video/status/:videoId", async (req, res) => {
    if (!ENV.agnesApiKey) {
      res.status(503).json({ error: "Video API is not configured on the server." });
      return;
    }
    try {
      const upstream = await fetch(`https://apihub.agnes-ai.com/agnesapi?video_id=${encodeURIComponent(req.params.videoId)}`, {
        headers: { Authorization: `Bearer ${ENV.agnesApiKey}` },
      });
      const body = await upstream.json().catch(() => ({}));
      if (!upstream.ok) {
        res.status(upstream.status).json({ error: body?.error?.message ?? body?.message ?? "Video status request failed." });
        return;
      }
      res.json(body);
    } catch (error) {
      console.error("[video] status request failed", error);
      res.status(502).json({ error: "Could not reach the video provider." });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[api] server listening on port ${port}`);
  });
}

startServer().catch(console.error);
