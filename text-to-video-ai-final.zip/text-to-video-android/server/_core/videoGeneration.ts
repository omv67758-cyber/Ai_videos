/**
 * Text-to-video generation helper using the Agnes AI video API.
 * Official docs: https://agnes-ai.com/en/docs/agnes-video-v20
 *
 * Set these env vars (see .env):
 *   VIDEO_API_KEY=sk-...
 *   VIDEO_API_BASE_URL=https://apihub.agnes-ai.com/v1/videos   (optional, has a default)
 *   VIDEO_API_STATUS_URL=https://apihub.agnes-ai.com/agnesapi  (optional, has a default)
 *   VIDEO_API_MODEL=agnes-video-v2.0                            (optional, has a default)
 *
 * Flow:
 *   1. startVideoGeneration({ prompt }) -> { videoId }          (kicks off generation, async)
 *   2. checkVideoStatus(videoId) -> { status, progress, url }   (poll this every few seconds)
 *   3. once status === "completed", download metadata.url and store it (storagePut) so it has
 *      a permanent app URL instead of the provider's URL.
 */
import { storagePut } from "../storage";
import { ENV } from "./env";

const QUALITY_SUFFIX =
  ", cinematic lighting, ultra detailed, sharp focus, high resolution, smooth motion, realistic textures, professional color grading";

const NEGATIVE_PROMPT =
  "pc game, console game, video game, cartoon, childish, low quality, worst quality, blurry, jittery, distorted, inconsistent appearance, watermark, text, deformed, extra limbs";

// num_frames must be <= 441 and follow the "8n + 1" rule (81, 121, 241, 441 ...)
const DURATION_PRESETS: Record<number, { num_frames: number; frame_rate: number }> = {
  3: { num_frames: 81, frame_rate: 24 },
  5: { num_frames: 121, frame_rate: 24 },
  10: { num_frames: 241, frame_rate: 24 },
  18: { num_frames: 441, frame_rate: 24 },
};

function closestDurationPreset(seconds: number) {
  const keys = Object.keys(DURATION_PRESETS).map(Number);
  const nearest = keys.reduce((a, b) => (Math.abs(b - seconds) < Math.abs(a - seconds) ? b : a));
  return DURATION_PRESETS[nearest];
}

// "16:9" -> { width, height } from Agnes's supported resolution tiers
const ASPECT_RATIO_SIZES: Record<string, { width: number; height: number }> = {
  "16:9": { width: 1152, height: 768 },
  "9:16": { width: 768, height: 1152 },
  "1:1": { width: 960, height: 960 },
  "4:3": { width: 1152, height: 864 },
  "3:4": { width: 864, height: 1152 },
};

export type StartVideoGenerationOptions = {
  prompt: string;
  /** Target seconds — snapped to the nearest supported num_frames/frame_rate preset. */
  duration?: number;
  /** e.g. "16:9", "9:16", "1:1", "4:3", "3:4". Defaults to 16:9. */
  aspectRatio?: string;
  seed?: number;
};

export type StartVideoGenerationResponse = {
  videoId: string;
  taskId: string;
};

function requireVideoConfig() {
  if (!ENV.videoApiKey) {
    throw new Error("VIDEO_API_KEY is not configured");
  }
}

export async function startVideoGeneration(
  options: StartVideoGenerationOptions,
): Promise<StartVideoGenerationResponse> {
  requireVideoConfig();

  const { num_frames, frame_rate } = closestDurationPreset(options.duration ?? 5);
  const { width, height } = ASPECT_RATIO_SIZES[options.aspectRatio ?? "16:9"] ?? ASPECT_RATIO_SIZES["16:9"];

  const response = await fetch(ENV.videoApiBaseUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${ENV.videoApiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: ENV.videoApiModel,
      prompt: options.prompt.trim() + QUALITY_SUFFIX,
      negative_prompt: NEGATIVE_PROMPT,
      width,
      height,
      num_frames,
      frame_rate,
      ...(options.seed !== undefined ? { seed: options.seed } : {}),
    }),
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Video generation request failed (${response.status})${detail ? `: ${detail}` : ""}`);
  }

  const data = (await response.json()) as { video_id?: string; task_id?: string; id?: string };
  const videoId = data.video_id ?? data.id;
  const taskId = data.task_id ?? data.id;
  if (!videoId || !taskId) {
    throw new Error("Agnes AI did not return a video_id/task_id");
  }

  return { videoId, taskId };
}

export type VideoStatus = "queued" | "in_progress" | "completed" | "failed";

export type CheckVideoStatusResponse = {
  status: VideoStatus;
  progress: number;
  /** Only set once status === "completed". Comes from metadata.url — download + storagePut it. */
  providerUrl?: string;
  error?: string;
};

export async function checkVideoStatus(videoId: string): Promise<CheckVideoStatusResponse> {
  requireVideoConfig();

  const statusUrl = new URL(ENV.videoApiStatusUrl);
  statusUrl.searchParams.set("video_id", videoId);

  const response = await fetch(statusUrl, {
    headers: { Authorization: `Bearer ${ENV.videoApiKey}` },
  });

  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`Video status check failed (${response.status})${detail ? `: ${detail}` : ""}`);
  }

  const data = (await response.json()) as {
    status?: string;
    progress?: number;
    metadata?: { url?: string };
    error?: { message?: string } | null;
  };

  const status = (data.status as VideoStatus) ?? "in_progress";

  return {
    status,
    progress: data.progress ?? 0,
    providerUrl: status === "completed" ? data.metadata?.url : undefined,
    error: status === "failed" ? (data.error?.message ?? "Generation failed") : undefined,
  };
}

/**
 * Downloads a completed video from Agnes AI's result URL and re-uploads it to
 * app storage, returning a permanent /manus-storage/... URL.
 */
export async function persistGeneratedVideo(providerUrl: string): Promise<{ url: string }> {
  const response = await fetch(providerUrl);
  if (!response.ok) {
    throw new Error(`Failed to download generated video (${response.status})`);
  }
  const buffer = Buffer.from(await response.arrayBuffer());
  const { url } = await storagePut(`generated-videos/${Date.now()}.mp4`, buffer, "video/mp4");
  return { url };
}
