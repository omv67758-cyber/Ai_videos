import { z } from "zod";
import { checkVideoStatus, persistGeneratedVideo, startVideoGeneration } from "./videoGeneration";
import { protectedProcedure, router } from "./trpc";

export const videoRouter = router({
  generate: protectedProcedure
    .input(
      z.object({
        prompt: z.string().min(1, "Prompt is required").max(1000),
        duration: z.number().min(1).max(18).optional(),
        aspectRatio: z.enum(["16:9", "9:16", "1:1", "4:3", "3:4"]).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { videoId } = await startVideoGeneration(input);
      return { videoId };
    }),

  status: protectedProcedure
    .input(z.object({ videoId: z.string().min(1) }))
    .query(async ({ input }) => {
      const result = await checkVideoStatus(input.videoId);

      if (result.status === "completed" && result.providerUrl) {
        // Re-host on our own storage so the link doesn't expire.
        const { url } = await persistGeneratedVideo(result.providerUrl);
        return { ...result, url };
      }

      return { ...result, url: undefined };
    }),
});
