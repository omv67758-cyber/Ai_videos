import { useMemo, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { ScreenContainer } from "@/components/screen-container";

const styles = ["Cinematic", "Anime", "Product", "Realistic"];
const ratios = ["16:9", "9:16", "1:1"];

export default function HomeScreen() {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("Cinematic");
  const [ratio, setRatio] = useState("16:9");
  const [duration, setDuration] = useState("8 sec");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);

  const promptLength = useMemo(() => prompt.length, [prompt]);

  const handleGenerate = () => {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setGenerated(false);
    // API endpoint will be connected here after the provider documentation is received.
    setTimeout(() => {
      setIsGenerating(false);
      setGenerated(true);
    }, 1400);
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]}>
      <ScrollView
        contentContainerStyle={stylesSheet.content}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={stylesSheet.header}>
          <View>
            <Text style={stylesSheet.eyebrow}>CREATOR STUDIO</Text>
            <Text style={stylesSheet.title}>Make it move.</Text>
            <Text style={stylesSheet.subtitle}>Turn an idea into a cinematic clip.</Text>
          </View>
          <View style={stylesSheet.avatar}>
            <Text style={stylesSheet.avatarText}>A</Text>
          </View>
        </View>

        <View style={stylesSheet.previewCard}>
          <View style={stylesSheet.previewGlow} />
          <View style={stylesSheet.previewTopRow}>
            <View style={stylesSheet.livePill}>
              <View style={stylesSheet.liveDot} />
              <Text style={stylesSheet.liveText}>{generated ? "READY" : "PREVIEW"}</Text>
            </View>
            <Text style={stylesSheet.previewMeta}>{ratio}  ·  {duration}</Text>
          </View>
          <View style={stylesSheet.previewCenter}>
            <View style={stylesSheet.playCircle}>
              <MaterialIcons name={generated ? "play-arrow" : "auto-awesome"} size={27} color="#11131B" />
            </View>
            <Text style={stylesSheet.previewHint}>
              {generated ? "Your concept is ready" : "Your video will appear here"}
            </Text>
          </View>
          <View style={stylesSheet.timeline}>
            <View style={[stylesSheet.timelineFill, { width: generated ? "100%" : "36%" }]} />
          </View>
        </View>

        <View style={stylesSheet.sectionHeader}>
          <Text style={stylesSheet.sectionTitle}>Describe your scene</Text>
          <Text style={stylesSheet.counter}>{promptLength}/500</Text>
        </View>
        <View style={stylesSheet.promptBox}>
          <TextInput
            value={prompt}
            onChangeText={setPrompt}
            placeholder="A neon-lit train gliding through Tokyo at midnight..."
            placeholderTextColor="#73778A"
            multiline
            maxLength={500}
            textAlignVertical="top"
            style={stylesSheet.promptInput}
          />
          <View style={stylesSheet.promptFooter}>
            <Text style={stylesSheet.promptTip}>Be specific about camera, mood and motion</Text>
            <MaterialIcons name="auto-awesome" size={18} color="#B6A5FF" />
          </View>
        </View>

        <Text style={stylesSheet.sectionTitle}>Visual style</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={stylesSheet.chipRow}>
          {styles.map((item) => (
            <Pressable
              key={item}
              onPress={() => setStyle(item)}
              style={({ pressed }) => [stylesSheet.chip, style === item && stylesSheet.chipActive, pressed && stylesSheet.pressed]}
            >
              <Text style={[stylesSheet.chipText, style === item && stylesSheet.chipTextActive]}>{item}</Text>
            </Pressable>
          ))}
        </ScrollView>

        <View style={stylesSheet.controlsRow}>
          <View style={stylesSheet.controlBlock}>
            <Text style={stylesSheet.controlLabel}>Aspect ratio</Text>
            <View style={stylesSheet.segmentRow}>
              {ratios.map((item) => (
                <Pressable key={item} onPress={() => setRatio(item)} style={({ pressed }) => [stylesSheet.segment, ratio === item && stylesSheet.segmentActive, pressed && stylesSheet.pressed]}>
                  <Text style={[stylesSheet.segmentText, ratio === item && stylesSheet.segmentTextActive]}>{item}</Text>
                </Pressable>
              ))}
            </View>
          </View>
          <View style={stylesSheet.controlBlockSmall}>
            <Text style={stylesSheet.controlLabel}>Length</Text>
            <Pressable onPress={() => setDuration(duration === "8 sec" ? "6 sec" : "8 sec")} style={({ pressed }) => [stylesSheet.lengthButton, pressed && stylesSheet.pressed]}>
              <Text style={stylesSheet.lengthText}>{duration}</Text>
              <MaterialIcons name="unfold-more" size={17} color="#B6A5FF" />
            </Pressable>
          </View>
        </View>

        <Pressable
          onPress={handleGenerate}
          disabled={!prompt.trim() || isGenerating}
          style={({ pressed }) => [stylesSheet.generateButton, (!prompt.trim() || isGenerating) && stylesSheet.generateDisabled, pressed && stylesSheet.pressed]}
        >
          <MaterialIcons name={isGenerating ? "hourglass-top" : "auto-awesome"} size={20} color="#11131B" />
          <Text style={stylesSheet.generateText}>{isGenerating ? "Creating your clip..." : "Generate video"}</Text>
          {!isGenerating && <Text style={stylesSheet.creditText}>1 credit</Text>}
        </Pressable>

        <Text style={stylesSheet.footerNote}>Free plan · API connection pending · No watermark</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const stylesSheet = StyleSheet.create({
  content: { padding: 22, paddingBottom: 40, gap: 16 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 5 },
  eyebrow: { color: "#A894FF", fontSize: 11, fontWeight: "800", letterSpacing: 2.2, marginBottom: 8 },
  title: { color: "#F3F1F8", fontSize: 32, fontWeight: "800", letterSpacing: -1.1 },
  subtitle: { color: "#8D90A3", fontSize: 14, marginTop: 4 },
  avatar: { width: 38, height: 38, borderRadius: 19, backgroundColor: "#28243A", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#4B416E" },
  avatarText: { color: "#D6CAFF", fontWeight: "800", fontSize: 15 },
  previewCard: { height: 205, borderRadius: 24, overflow: "hidden", backgroundColor: "#171824", borderWidth: 1, borderColor: "#302E42", padding: 16 },
  previewGlow: { position: "absolute", width: 240, height: 160, borderRadius: 120, backgroundColor: "#362A70", opacity: 0.5, top: 45, left: 45 },
  previewTopRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  livePill: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#222334", borderRadius: 20, paddingHorizontal: 9, paddingVertical: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#A894FF" },
  liveText: { color: "#C3BAE8", fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  previewMeta: { color: "#85889A", fontSize: 11, fontWeight: "700" },
  previewCenter: { flex: 1, alignItems: "center", justifyContent: "center" },
  playCircle: { width: 58, height: 58, borderRadius: 29, backgroundColor: "#B6A5FF", alignItems: "center", justifyContent: "center", shadowColor: "#B6A5FF", shadowOpacity: 0.35, shadowRadius: 18 },
  previewHint: { color: "#B5B5C5", fontSize: 12, marginTop: 10 },
  timeline: { height: 3, backgroundColor: "#353548", borderRadius: 2, overflow: "hidden" },
  timelineFill: { height: "100%", backgroundColor: "#A894FF", borderRadius: 2 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 4 },
  sectionTitle: { color: "#EDEBF4", fontSize: 16, fontWeight: "700" },
  counter: { color: "#6F7182", fontSize: 11, fontWeight: "700" },
  promptBox: { backgroundColor: "#1A1B27", borderRadius: 18, borderWidth: 1, borderColor: "#353446", minHeight: 132, padding: 14 },
  promptInput: { color: "#F4F2F8", fontSize: 15, lineHeight: 23, minHeight: 74 },
  promptFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 8 },
  promptTip: { color: "#777A8D", fontSize: 11 },
  chipRow: { gap: 8, paddingTop: 1, paddingBottom: 2 },
  chip: { borderRadius: 20, borderWidth: 1, borderColor: "#353446", backgroundColor: "#1B1C28", paddingHorizontal: 15, paddingVertical: 10 },
  chipActive: { backgroundColor: "#352E57", borderColor: "#8974D4" },
  chipText: { color: "#9698A8", fontSize: 13, fontWeight: "700" },
  chipTextActive: { color: "#DCD4FF" },
  controlsRow: { flexDirection: "row", gap: 12 },
  controlBlock: { flex: 1 },
  controlBlockSmall: { width: 103 },
  controlLabel: { color: "#7F8192", fontSize: 11, fontWeight: "700", marginBottom: 8 },
  segmentRow: { flexDirection: "row", backgroundColor: "#1A1B27", borderRadius: 12, padding: 3, borderWidth: 1, borderColor: "#303140" },
  segment: { flex: 1, alignItems: "center", paddingVertical: 9, borderRadius: 9 },
  segmentActive: { backgroundColor: "#38305B" },
  segmentText: { color: "#777A8D", fontSize: 11, fontWeight: "800" },
  segmentTextActive: { color: "#D8CEFF" },
  lengthButton: { height: 40, backgroundColor: "#1A1B27", borderRadius: 12, borderWidth: 1, borderColor: "#303140", flexDirection: "row", alignItems: "center", justifyContent: "space-around" },
  lengthText: { color: "#D5D1E0", fontSize: 12, fontWeight: "700" },
  generateButton: { height: 54, borderRadius: 17, backgroundColor: "#B6A5FF", alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 9, marginTop: 3, shadowColor: "#B6A5FF", shadowOpacity: 0.22, shadowRadius: 15, shadowOffset: { width: 0, height: 7 }, elevation: 5 },
  generateDisabled: { opacity: 0.42 },
  generateText: { color: "#11131B", fontSize: 15, fontWeight: "800" },
  creditText: { color: "#51477A", fontSize: 11, fontWeight: "800", marginLeft: 4 },
  footerNote: { textAlign: "center", color: "#626576", fontSize: 11, marginTop: -3 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.98 }] },
});
