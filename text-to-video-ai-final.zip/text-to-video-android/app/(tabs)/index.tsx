import { useState } from "react";
import { ActivityIndicator, Alert, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as FileSystem from "expo-file-system/legacy";
import * as MediaLibrary from "expo-media-library";

import { ScreenContainer } from "@/components/screen-container";
import { apiCall } from "@/lib/_core/api";

const ratios = ["16:9", "9:16", "1:1"];

export default function HomeScreen() {
  const [prompt, setPrompt] = useState("");
  const [ratio, setRatio] = useState("16:9");
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [statusText, setStatusText] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setVideoUrl(null);
    setError(null);
    setProgress(2);
    setElapsedSeconds(0);
    setStatusText("Submitting your prompt…");
    const startedAt = Date.now();

    try {
      const task = await apiCall<{ video_id?: string; task_id?: string }>("/api/video/generate", {
        method: "POST",
        body: JSON.stringify({
          prompt: prompt.trim(),
          ratio,
        }),
      });
      const videoId = task.video_id ?? task.task_id;
      if (!videoId) throw new Error("Video task ID was not returned.");
      setProgress(5);
      setStatusText("Thinking about your scene…");

      for (let attempt = 0; attempt < 60; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, 5000));
        setElapsedSeconds(Math.floor((Date.now() - startedAt) / 1000));
        const result = await apiCall<{
          status?: string;
          progress?: number;
          metadata?: { url?: string };
          error?: { message?: string };
        }>(`/api/video/status/${encodeURIComponent(videoId)}`);

        const nextProgress = Math.max(5, Math.min(99, result.progress ?? Math.min(95, 8 + attempt * 2)));
        setProgress(nextProgress);
        setStatusText(nextProgress < 35 ? "Planning the motion…" : nextProgress < 75 ? "Creating your video…" : "Finishing the details…");

        if (result.status === "completed" && result.metadata?.url) {
          setVideoUrl(result.metadata.url);
          setProgress(100);
          setStatusText("Video ready");
          break;
        }
        if (result.status === "failed") {
          throw new Error(result.error?.message ?? "Video generation failed.");
        }
        if (attempt === 59) throw new Error("Generation timed out. Please try again.");
      }
    } catch (generationError) {
      setError(generationError instanceof Error ? generationError.message : "Video generation failed.");
    } finally {
      setIsGenerating(false);
    }
  };

  const saveVideo = async () => {
    if (!videoUrl || isSaving) return;
    setIsSaving(true);
    try {
      const localUri = `${FileSystem.cacheDirectory}ai-video-${Date.now()}.mp4`;
      const downloaded = await FileSystem.downloadAsync(videoUrl, localUri);
      if (Platform.OS === "android") {
        const directory = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
        if (directory.granted) {
          const destination = await FileSystem.StorageAccessFramework.createFileAsync(directory.directoryUri, `ai-video-${Date.now()}.mp4`, "video/mp4");
          await FileSystem.copyAsync({ from: downloaded.uri, to: destination });
          Alert.alert("Saved", "Video save ho gayi hai. Aapne jo folder select kiya tha, wahan mil jayegi.");
        } else {
          Alert.alert("Permission needed", "Video save karne ke liye Downloads folder select karein.");
        }
      } else {
        const permission = await MediaLibrary.requestPermissionsAsync();
        if (permission.granted) {
          await MediaLibrary.createAssetAsync(downloaded.uri);
          Alert.alert("Saved", "Video gallery mein save ho gayi hai.");
        }
      }
    } catch (saveError) {
      Alert.alert("Save failed", saveError instanceof Error ? saveError.message : "Video save nahi ho saki.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]}>
      <View style={styles.page}>
        <View style={styles.topBar}>
          <View style={styles.brandRow}>
            <View style={styles.logo}><MaterialIcons name="auto-awesome" size={18} color="#FFFFFF" /></View>
            <Text style={styles.brand}>AI Video</Text>
          </View>
          <Pressable style={({ pressed }) => [styles.moreButton, pressed && styles.pressed]}>
            <MaterialIcons name="more-vert" size={22} color="#686868" />
          </Pressable>
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.welcome}>
            <View style={styles.welcomeIcon}><MaterialIcons name="movie-creation" size={28} color="#FFFFFF" /></View>
            <Text style={styles.heading}>What video will we make?</Text>
            <Text style={styles.subheading}>Describe an idea and AI will turn it into a video.</Text>
          </View>

          <View style={styles.examples}>
            <Text style={styles.label}>Try an example</Text>
            <Pressable onPress={() => setPrompt("A cinematic drone shot flying over snowy mountains at sunrise")} style={({ pressed }) => [styles.example, pressed && styles.pressed]}>
              <MaterialIcons name="landscape" size={18} color="#777777" />
              <Text style={styles.exampleText}>Cinematic mountains at sunrise</Text>
              <MaterialIcons name="arrow-forward" size={17} color="#999999" />
            </Pressable>
            <Pressable onPress={() => setPrompt("A tiny robot exploring a glowing futuristic city in the rain")} style={({ pressed }) => [styles.example, pressed && styles.pressed]}>
              <MaterialIcons name="smart-toy" size={18} color="#777777" />
              <Text style={styles.exampleText}>Robot in a futuristic city</Text>
              <MaterialIcons name="arrow-forward" size={17} color="#999999" />
            </Pressable>
          </View>

          <View style={styles.composer}>
            <TextInput
              value={prompt}
              onChangeText={setPrompt}
              placeholder="Describe the video you want to create..."
              placeholderTextColor="#929292"
              multiline
              maxLength={500}
              style={styles.input}
            />
            <View style={styles.composerBottom}>
              <Text style={styles.counter}>{prompt.length}/500</Text>
              <Pressable onPress={handleGenerate} disabled={!prompt.trim() || isGenerating} style={({ pressed }) => [styles.sendButton, (!prompt.trim() || isGenerating) && styles.sendDisabled, pressed && styles.pressed]}>
                <MaterialIcons name={isGenerating ? "hourglass-top" : "arrow-upward"} size={20} color="#FFFFFF" />
              </Pressable>
            </View>
          </View>

          <View style={styles.optionsCard}>
            <View style={styles.optionHeader}><Text style={styles.label}>Video options</Text><MaterialIcons name="tune" size={18} color="#777777" /></View>
            <Text style={styles.optionLabel}>Aspect ratio</Text>
            <View style={styles.ratioRow}>
              {ratios.map((item) => (
                <Pressable key={item} onPress={() => setRatio(item)} style={({ pressed }) => [styles.ratio, ratio === item && styles.ratioActive, pressed && styles.pressed]}>
                  <Text style={[styles.ratioText, ratio === item && styles.ratioTextActive]}>{item}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          {isGenerating && <View style={styles.progressCard}>
            <View style={styles.progressHeader}><Text style={styles.status}>{statusText}</Text><Text style={styles.progressPercent}>{progress}%</Text></View>
            <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${progress}%` }]} /></View>
            <View style={styles.progressFooter}><Text style={styles.progressHint}>Live generation status</Text><Text style={styles.progressHint}>{elapsedSeconds}s elapsed</Text></View>
            <ActivityIndicator size="small" color="#202123" style={styles.spinner} />
          </View>}
          {videoUrl && <View style={styles.resultGroup}>
            <Pressable onPress={() => Linking.openURL(videoUrl)} style={styles.resultButton}><MaterialIcons name="play-circle-outline" size={20} color="#FFFFFF" /><Text style={styles.resultText}>Preview video</Text></Pressable>
            <Pressable onPress={saveVideo} disabled={isSaving} style={({ pressed }) => [styles.saveButton, isSaving && styles.saveDisabled, pressed && styles.pressed]}><MaterialIcons name="download" size={20} color="#202123" /><Text style={styles.saveText}>{isSaving ? "Saving video…" : "Download video"}</Text></Pressable>
          </View>}
          {error && <Text style={styles.error}>{error}</Text>}
          <Text style={styles.footer}>Powered by Agnes AI · Free limits may apply</Text>
        </ScrollView>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: "#F7F7F8" },
  topBar: { height: 62, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: "#E7E7E7", backgroundColor: "#FFFFFF" },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  logo: { width: 32, height: 32, borderRadius: 9, backgroundColor: "#202123", alignItems: "center", justifyContent: "center" },
  brand: { color: "#202123", fontSize: 17, fontWeight: "700" },
  moreButton: { width: 38, height: 38, alignItems: "center", justifyContent: "center" },
  content: { padding: 18, paddingBottom: 34, gap: 18 },
  welcome: { alignItems: "center", paddingTop: 30, paddingBottom: 10 },
  welcomeIcon: { width: 58, height: 58, borderRadius: 18, backgroundColor: "#202123", alignItems: "center", justifyContent: "center", marginBottom: 16 },
  heading: { color: "#202123", fontSize: 23, fontWeight: "700", textAlign: "center" },
  subheading: { color: "#777777", fontSize: 14, marginTop: 8, textAlign: "center" },
  examples: { gap: 9 },
  label: { color: "#606060", fontSize: 12, fontWeight: "700", marginBottom: 2 },
  example: { minHeight: 48, paddingHorizontal: 14, borderRadius: 12, borderWidth: 1, borderColor: "#E2E2E2", backgroundColor: "#FFFFFF", flexDirection: "row", alignItems: "center", gap: 10 },
  exampleText: { flex: 1, color: "#454545", fontSize: 14 },
  composer: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#D7D7D7", borderRadius: 16, padding: 12, shadowColor: "#000000", shadowOpacity: 0.04, shadowRadius: 5, elevation: 2 },
  input: { minHeight: 74, maxHeight: 130, color: "#202123", fontSize: 15, lineHeight: 22, textAlignVertical: "top" },
  composerBottom: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 8 },
  counter: { color: "#999999", fontSize: 11 },
  sendButton: { width: 36, height: 36, borderRadius: 18, backgroundColor: "#202123", alignItems: "center", justifyContent: "center" },
  sendDisabled: { backgroundColor: "#BDBDBD" },
  optionsCard: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E2E2E2", borderRadius: 14, padding: 14, gap: 10 },
  optionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  optionLabel: { color: "#777777", fontSize: 12, fontWeight: "600" },
  ratioRow: { flexDirection: "row", gap: 8 },
  ratio: { flex: 1, height: 38, borderRadius: 9, backgroundColor: "#F3F3F3", alignItems: "center", justifyContent: "center" },
  ratioActive: { backgroundColor: "#202123" },
  ratioText: { color: "#777777", fontSize: 12, fontWeight: "700" },
  ratioTextActive: { color: "#FFFFFF" },
  durationRow: { borderTopWidth: 1, borderTopColor: "#EEEEEE", paddingTop: 11, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  durationValue: { flexDirection: "row", alignItems: "center", gap: 5 },
  durationText: { color: "#333333", fontSize: 13, fontWeight: "700" },
  status: { color: "#666666", fontSize: 12, lineHeight: 18, textAlign: "center" },
  progressCard: { backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: "#E2E2E2", borderRadius: 14, padding: 14, gap: 9 },
  progressHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  progressPercent: { color: "#202123", fontSize: 13, fontWeight: "800" },
  progressTrack: { height: 9, borderRadius: 5, backgroundColor: "#E7E7E7", overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 5, backgroundColor: "#202123" },
  progressFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  progressHint: { color: "#999999", fontSize: 11 },
  spinner: { position: "absolute", right: 14, top: 14 },
  resultGroup: { gap: 9 },
  resultButton: { height: 48, borderRadius: 13, backgroundColor: "#202123", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  resultText: { color: "#FFFFFF", fontSize: 14, fontWeight: "700" },
  saveButton: { height: 48, borderRadius: 13, backgroundColor: "#E7E7E7", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  saveDisabled: { opacity: 0.55 },
  saveText: { color: "#202123", fontSize: 14, fontWeight: "700" },
  error: { color: "#B3261E", fontSize: 12, lineHeight: 18, textAlign: "center" },
  footer: { color: "#999999", fontSize: 11, textAlign: "center", marginTop: 2 },
  pressed: { opacity: 0.72 },
});
